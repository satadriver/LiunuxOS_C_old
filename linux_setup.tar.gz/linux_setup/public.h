

#define FALSE 0
#define TRUE 1
#define LONG long

#define WORD unsigned short
#define DWORD unsigned long

#define BYTE unsigned char
#define __int64  long long

#define MAX_PATH 1024


