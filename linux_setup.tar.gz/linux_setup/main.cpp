
#include <stdio.h>


#include "writeos.h"






int main(int argc, char ** argv) {

	int result = 0;

	OSReaderWriter writeros;
	writeros.osWriter();

	return 0;
}
