

extern int g_workfunc_var;

int workfunc(int x,int y);
