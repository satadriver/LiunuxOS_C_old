

#include <stdio.h>

extern "C" int g_function_c;

extern "C" int function_c(int x,int y);
